# Building Management System — Phase 1

This is **Phase 1** of the full build: project foundation, config system,
theming, three-language support, and both login flows (Resident + Admin)
working end-to-end against real Firebase Auth + Firestore.

## What's included in this phase
- Vite + React + Tailwind scaffold, PWA-installable (manifest + service worker via `vite-plugin-pwa`)
- `src/config/config.js` — single file to rebrand/reconfigure the whole app
- Language selection screen + English/Telugu/Urdu translations, switchable anytime, RTL handled for Urdu
- Dark/light mode with persistence
- Resident login (Room Number + Password) and Admin login, both backed by **real Firebase Authentication**
- Firestore security rules matching the resident/admin data-access model
- Dashboard shells for both roles (stat cards, nav) ready to wire up to live data

## Why Firebase Auth instead of a plain Firestore password check
Firestore Security Rules can only restrict data based on `request.auth` —
they can't see a plaintext password field. So residents log in with
**Room Number + Password**, but under the hood that's turned into a real
Firebase Auth account with a synthesized email
(`101@srisairesidency.residents.local`) — residents never see this. This
gets you actual secure, free authentication without needing Cloud Functions
or the Blaze billing plan.

When the admin creates a new resident, the app briefly spins up a *second*,
throwaway Firebase App instance to create that resident's Auth account —
this avoids the well-known issue where creating a user on the client signs
you in as them (which would kick the admin out of their own session). See
`createResidentAccount` in `src/services/authService.js`.

## Setup
```bash
npm install
cp .env.example .env   # fill in your Firebase project's config values
npm run dev
```

You'll also need to, once, in the Firebase console:
1. Enable **Email/Password** sign-in under Authentication.
2. Enable **Firestore** in production mode.
3. Manually create your first admin: Authentication → Add user with an
   email like `admin@srisairesidency.residents.local`, then in Firestore
   create a matching document at `admins/{that user's UID}` with an
   `{ name: "..." }` field. After that, the admin can create all residents
   from inside the app.
4. Deploy rules: `firebase deploy --only firestore:rules`

## Remaining phases (not yet built)
This prompt described a genuinely large system — building it well in one
pass isn't realistic, so here's the planned order. Each phase is a working,
testable slice:

- **Phase 2 — Resident money flows**: My Maintenance (dues + UPI QR + `upi://pay`
  link generation), "I Have Paid" submission flow, digital Passbook
- **Phase 3 — Admin resident & payment management**: Resident Directory
  (CRUD + search), Payment Requests approval/rejection, auto-updating
  collection stats
- **Phase 4 — Expenses, Notifications, Emergency Contacts**: admin CRUD for
  each, resident-facing notification feed + one-tap emergency calling
- **Phase 5 — Reports & automation**: jsPDF monthly reports, automatic
  monthly due generation, Activity Logs
- **Phase 6 — Push notifications**: Firebase Cloud Messaging wiring,
  service worker background handler
- **Phase 7 — Charts & polish**: Recharts dashboards, offline UX, loading/
  empty/error states pass, final PWA icon set

## A note on this environment
This was built in a sandbox without network access, so dependencies haven't
been installed or build-tested here. Recommend continuing this build in
**Claude Code** (desktop or terminal) or **Cowork**, where `npm install`,
the dev server, and `firebase deploy` can actually run — I'm happy to
keep building phases here in the meantime if you'd rather continue in chat.
