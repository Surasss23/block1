import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
} from 'firebase/auth';
import { initializeApp, deleteApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { app, auth, db } from '../firebase/firebase';
import { APP } from '../config/config';

const roomToEmail = (roomNumber) =>
  `${String(roomNumber).trim().toLowerCase()}@${APP.authEmailDomain}`;

/**
 * Resident login: Room Number + Password.
 * Under the hood this is real Firebase Auth (email/password), with the
 * "email" synthesized from the room number so residents never see it.
 */
export async function residentLogin(roomNumber, password) {
  const email = roomToEmail(roomNumber);
  const cred = await signInWithEmailAndPassword(auth, email, password);
  const profileSnap = await getDoc(doc(db, 'residents', cred.user.uid));
  if (!profileSnap.exists()) {
    await signOut(auth);
    throw new Error('resident-profile-missing');
  }
  return { uid: cred.user.uid, profile: profileSnap.data() };
}

/**
 * Admin login: username + password, also backed by Firebase Auth.
 * Admin "username" is mapped to an email the same way residents are, using
 * a separate admins/ Firestore collection to distinguish the account type.
 */
export async function adminLogin(username, password) {
  const email = `${String(username).trim().toLowerCase()}@${APP.authEmailDomain}`;
  const cred = await signInWithEmailAndPassword(auth, email, password);
  const profileSnap = await getDoc(doc(db, 'admins', cred.user.uid));
  if (!profileSnap.exists()) {
    await signOut(auth);
    throw new Error('not-an-admin-account');
  }
  return { uid: cred.user.uid, profile: profileSnap.data() };
}

export function logout() {
  return signOut(auth);
}

export function subscribeToAuthChanges(callback) {
  return onAuthStateChanged(auth, callback);
}

/**
 * Admin-only: create a brand-new resident login (Room Number + Password).
 *
 * Firebase Auth's client SDK signs you in as whichever user you just created,
 * which would normally kick the admin out of their own session. We avoid
 * that — and avoid needing Cloud Functions / Blaze billing — by spinning up
 * a *second*, temporary Firebase App instance just for this one operation,
 * then tearing it down. The admin's real session (on the primary `auth`
 * instance) is never touched.
 */
export async function createResidentAccount({ roomNumber, password, residentData }) {
  const email = roomToEmail(roomNumber);
  const tempApp = initializeApp(app.options, `create-resident-${Date.now()}`);
  const tempAuth = getAuth(tempApp);
  try {
    const cred = await createUserWithEmailAndPassword(tempAuth, email, password);
    await setDoc(doc(db, 'residents', cred.user.uid), {
      roomNumber,
      ...residentData,
      status: 'active',
      createdAt: serverTimestamp(),
    });
    await signOut(tempAuth);
    return cred.user.uid;
  } finally {
    await deleteApp(tempApp);
  }
}
