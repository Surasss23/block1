import { Navigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

function FullScreenLoader() {
  return (
    <div className="flex h-screen items-center justify-center">
      <div className="h-8 w-8 animate-spin rounded-full border-4 border-brand-500 border-t-transparent" />
    </div>
  );
}

export function RequireResident({ children }) {
  const { user, role, initializing } = useAuth();
  if (initializing) return <FullScreenLoader />;
  if (!user || role !== 'resident') return <Navigate to="/login/resident" replace />;
  return children;
}

export function RequireAdmin({ children }) {
  const { user, role, initializing } = useAuth();
  if (initializing) return <FullScreenLoader />;
  if (!user || role !== 'admin') return <Navigate to="/login/admin" replace />;
  return children;
}
