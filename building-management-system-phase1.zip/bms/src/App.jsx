import { Routes, Route, Navigate } from 'react-router-dom';
import { useLanguage } from './contexts/LanguageContext';
import LanguageSelect from './pages/LanguageSelect';
import Login from './pages/Login';
import ResidentDashboard from './pages/ResidentDashboard';
import AdminDashboard from './pages/AdminDashboard';
import { RequireResident, RequireAdmin } from './components/RouteGuards';

export default function App() {
  const { language } = useLanguage();

  return (
    <Routes>
      <Route path="/" element={language ? <Navigate to="/login/resident" replace /> : <LanguageSelect />} />
      <Route path="/language" element={<LanguageSelect />} />
      <Route path="/login/:portal" element={<Login />} />

      <Route path="/dashboard" element={<RequireResident><ResidentDashboard /></RequireResident>} />
      <Route path="/admin" element={<RequireAdmin><AdminDashboard /></RequireAdmin>} />

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
