// ============================================================================
// GLOBAL CONFIGURATION
// Edit values in this file to rebrand or reconfigure the entire app.
// Nothing here should ever be duplicated/hardcoded inside components/pages —
// always import from here instead.
//
// Secrets (Firebase keys, admin password) come from .env, NOT this file,
// since this file is committed to source control. See .env.example.
// ============================================================================

export const BUILDING = {
  name: 'Sri Sai Residency',
  address: '12-3-456, Road No. 5, Hyderabad, Telangana - 500001',
  logoUrl: '/assets/logo.png',
  supportPhone: '+91 90000 00000',
  supportEmail: 'office@srisairesidency.example',
};

export const ADMIN = {
  // Real credential check happens against Firebase Auth / Firestore, not here.
  // This just controls the *phone number displayed* to residents for contact.
  contactPhone: '+91 90000 00000',
};

export const PAYMENTS = {
  upiId: 'srisairesidency@okhdfcbank',
  upiPayeeName: 'Sri Sai Residency Association',
  currency: 'INR',
  currencySymbol: '₹',
  defaultMonthlyMaintenance: 2000,
  qrThemeColor: '#4f46e5',
};

export const EMERGENCY_CONTACTS = [
  { id: 'office', labelKey: 'emergency.buildingOffice', phone: '+91 90000 00001' },
  { id: 'watchman', labelKey: 'emergency.watchman', phone: '+91 90000 00002' },
  { id: 'supervisor', labelKey: 'emergency.maintenanceSupervisor', phone: '+91 90000 00003' },
  { id: 'electrician', labelKey: 'emergency.electrician', phone: '+91 90000 00004' },
  { id: 'plumber', labelKey: 'emergency.plumber', phone: '+91 90000 00005' },
  { id: 'lift', labelKey: 'emergency.liftService', phone: '+91 90000 00006' },
  { id: 'ambulance', labelKey: 'emergency.ambulance', phone: '108' },
  { id: 'fire', labelKey: 'emergency.fireDepartment', phone: '101' },
  { id: 'police', labelKey: 'emergency.policeStation', phone: '100' },
  { id: 'hospital', labelKey: 'emergency.hospital', phone: '+91 90000 00007' },
];

export const NOTIFICATION_CATEGORIES = [
  'general', 'emergency', 'maintenance', 'events', 'bills', 'waterSupply', 'electricityShutdown', 'custom',
];

export const EXPENSE_CATEGORIES = [
  'liftRepair', 'waterTankCleaning', 'electricityBill', 'securitySalary',
  'plumbingWork', 'painting', 'festivalExpenses', 'refund', 'other',
];

export const SUPPORTED_LANGUAGES = [
  { code: 'en', label: 'English', nativeLabel: 'English', dir: 'ltr' },
  { code: 'te', label: 'Telugu', nativeLabel: 'తెలుగు', dir: 'ltr' },
  { code: 'ur', label: 'Urdu', nativeLabel: 'اردو', dir: 'rtl' },
];

export const THEME = {
  defaultMode: 'light', // 'light' | 'dark'
  storageKey: 'bms_theme',
};

export const APP = {
  name: 'Building Management System',
  shortName: 'BMS',
  languageStorageKey: 'bms_language',
  sessionStorageKey: 'bms_session',
  // Firebase Auth needs an email+password pair even for "room number" login.
  // We synthesize one as `<roomNumber>@<authEmailDomain>` so residents never
  // see or type an email — this keeps everything on the free Spark plan
  // (no Cloud Functions / Admin SDK required) while still using real,
  // secure Firebase Authentication instead of hand-rolled password checks.
  authEmailDomain: 'srisairesidency.residents.local',
};

export default {
  BUILDING, ADMIN, PAYMENTS, EMERGENCY_CONTACTS,
  NOTIFICATION_CATEGORIES, EXPENSE_CATEGORIES, SUPPORTED_LANGUAGES, THEME, APP,
};
