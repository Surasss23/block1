import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { PAYMENTS } from '../config/config';

export default function ResidentDashboard() {
  const { profile, logout } = useAuth();
  const { t } = useLanguage();

  return (
    <div className="min-h-screen pb-24">
      <header className="bg-brand-600 px-6 pb-8 pt-10 text-white">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-brand-100">{t('dashboard.welcome')},</p>
            <h1 className="text-xl font-semibold">{profile?.name || '—'}</h1>
            <p className="text-sm text-brand-100">{t('login.roomNumber')}: {profile?.roomNumber}</p>
          </div>
          <button onClick={logout} className="rounded-full bg-white/15 px-3 py-1.5 text-sm">
            {t('common.logout')}
          </button>
        </div>
      </header>

      <main className="-mt-4 space-y-4 px-4">
        <div className="grid grid-cols-2 gap-3">
          <SummaryCard label={t('dashboard.currentStatus')} value={profile?.currentDue > 0 ? t('dashboard.unpaid') : t('dashboard.paid')} />
          <SummaryCard label={t('maintenance.pendingDue')} value={`${PAYMENTS.currencySymbol}${profile?.currentDue ?? 0}`} />
        </div>

        <section className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-700 dark:bg-slate-800">
          <h2 className="mb-2 font-semibold">{t('dashboard.notifications')}</h2>
          <p className="text-sm text-slate-400">{t('common.noData')}</p>
        </section>

        <section className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-700 dark:bg-slate-800">
          <h2 className="mb-2 font-semibold">{t('maintenance.title')}</h2>
          <p className="text-sm text-slate-400">{t('common.noData')}</p>
        </section>
      </main>
    </div>
  );
}

function SummaryCard({ label, value }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-700 dark:bg-slate-800">
      <p className="text-xs text-slate-500">{label}</p>
      <p className="mt-1 text-lg font-semibold">{value}</p>
    </div>
  );
}
