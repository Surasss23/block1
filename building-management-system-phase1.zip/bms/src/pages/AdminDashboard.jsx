import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { BUILDING, PAYMENTS } from '../config/config';

export default function AdminDashboard() {
  const { logout } = useAuth();
  const { t } = useLanguage();

  const stats = [
    { label: t('admin.totalResidents'), value: '—' },
    { label: t('admin.monthlyCollection'), value: `${PAYMENTS.currencySymbol}—` },
    { label: t('admin.totalExpenses'), value: `${PAYMENTS.currencySymbol}—` },
    { label: t('admin.pendingRequests'), value: '—' },
    { label: t('admin.netBalance'), value: `${PAYMENTS.currencySymbol}—` },
  ];

  return (
    <div className="min-h-screen pb-24">
      <header className="flex items-center justify-between bg-slate-900 px-6 py-5 text-white">
        <h1 className="text-lg font-semibold">{BUILDING.name} · Admin</h1>
        <button onClick={logout} className="rounded-full bg-white/15 px-3 py-1.5 text-sm">
          {t('common.logout')}
        </button>
      </header>

      <main className="space-y-4 px-4 py-4">
        <div className="grid grid-cols-2 gap-3">
          {stats.map((s) => (
            <div key={s.label} className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-700 dark:bg-slate-800">
              <p className="text-xs text-slate-500">{s.label}</p>
              <p className="mt-1 text-lg font-semibold">{s.value}</p>
            </div>
          ))}
        </div>

        <nav className="grid grid-cols-2 gap-3">
          {[
            t('admin.residentDirectory'),
            t('admin.expenses'),
            t('admin.notificationsManager'),
            t('admin.reports'),
            t('admin.activityLogs'),
          ].map((label) => (
            <button
              key={label}
              className="rounded-2xl border border-slate-200 bg-white p-4 text-left text-sm font-medium dark:border-slate-700 dark:bg-slate-800"
            >
              {label}
            </button>
          ))}
        </nav>
      </main>
    </div>
  );
}
