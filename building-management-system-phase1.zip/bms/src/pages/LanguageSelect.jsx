import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { BUILDING } from '../config/config';

export default function LanguageSelect() {
  const { languages, setLanguage, t } = useLanguage();
  const navigate = useNavigate();

  const choose = (code) => {
    setLanguage(code);
    navigate('/login/resident', { replace: true });
  };

  return (
    <div className="flex min-h-screen flex-col items-center justify-center px-6 py-12">
      <img src={BUILDING.logoUrl} alt="" className="mb-6 h-16 w-16 rounded-2xl object-cover shadow-sm" onError={(e) => { e.target.style.display = 'none'; }} />
      <h1 className="mb-1 text-center text-xl font-semibold">{BUILDING.name}</h1>
      <p className="mb-8 text-center text-sm text-slate-500">{t('languageSelect.title')}</p>

      <div className="w-full max-w-sm space-y-3">
        {languages.map((lang) => (
          <button
            key={lang.code}
            onClick={() => choose(lang.code)}
            className="flex w-full items-center justify-between rounded-2xl border border-slate-200 bg-white px-5 py-4 text-left shadow-sm transition active:scale-[0.98] dark:border-slate-700 dark:bg-slate-800"
          >
            <span className="text-base font-medium">{lang.nativeLabel}</span>
            <span className="text-sm text-slate-400">{lang.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
