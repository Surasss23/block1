import { useState } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { residentLogin, adminLogin } from '../services/authService';
import { BUILDING } from '../config/config';

export default function Login() {
  const { portal = 'resident' } = useParams(); // 'resident' | 'admin'
  const { t, language, languages, setLanguage } = useLanguage();
  const navigate = useNavigate();

  const [identifier, setIdentifier] = useState(''); // room number OR admin username
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const isAdmin = portal === 'admin';

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSubmitting(true);
    try {
      if (isAdmin) {
        await adminLogin(identifier, password);
        navigate('/admin', { replace: true });
      } else {
        await residentLogin(identifier, password);
        navigate('/dashboard', { replace: true });
      }
    } catch (err) {
      setError(t('login.invalidCredentials'));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="flex min-h-screen flex-col justify-center px-6 py-12">
      <div className="mx-auto w-full max-w-sm">
        <h1 className="mb-1 text-center text-lg font-semibold">{BUILDING.name}</h1>
        <p className="mb-6 text-center text-sm text-slate-500">{t('login.welcomeBack')}</p>

        {/* Portal tabs */}
        <div className="mb-6 flex rounded-xl bg-slate-100 p-1 dark:bg-slate-800">
          <Link
            to="/login/resident"
            className={`flex-1 rounded-lg py-2 text-center text-sm font-medium transition ${
              !isAdmin ? 'bg-white shadow-sm dark:bg-slate-700' : 'text-slate-500'
            }`}
          >
            {t('login.residentTab')}
          </Link>
          <Link
            to="/login/admin"
            className={`flex-1 rounded-lg py-2 text-center text-sm font-medium transition ${
              isAdmin ? 'bg-white shadow-sm dark:bg-slate-700' : 'text-slate-500'
            }`}
          >
            {t('login.adminTab')}
          </Link>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="mb-1 block text-sm font-medium">
              {isAdmin ? t('login.username') : t('login.roomNumber')}
            </label>
            <input
              type="text"
              required
              autoComplete="username"
              value={identifier}
              onChange={(e) => setIdentifier(e.target.value)}
              className="w-full rounded-xl border border-slate-300 px-4 py-3 text-base focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-200 dark:border-slate-700 dark:bg-slate-800"
            />
          </div>
          <div>
            <label className="mb-1 block text-sm font-medium">{t('login.password')}</label>
            <input
              type="password"
              required
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-xl border border-slate-300 px-4 py-3 text-base focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-200 dark:border-slate-700 dark:bg-slate-800"
            />
          </div>

          {error && <p className="text-sm text-red-600">{error}</p>}

          <button
            type="submit"
            disabled={submitting}
            className="w-full rounded-xl bg-brand-600 py-3 text-base font-semibold text-white transition active:scale-[0.98] disabled:opacity-60"
          >
            {submitting ? t('common.loading') : t('common.login')}
          </button>
        </form>

        <div className="mt-8 flex justify-center gap-3">
          {languages.map((lang) => (
            <button
              key={lang.code}
              onClick={() => setLanguage(lang.code)}
              className={`rounded-full px-3 py-1 text-xs font-medium ${
                language === lang.code ? 'bg-brand-100 text-brand-700' : 'text-slate-400'
              }`}
            >
              {lang.nativeLabel}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
