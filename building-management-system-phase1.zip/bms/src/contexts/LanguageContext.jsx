import { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { APP, SUPPORTED_LANGUAGES } from '../config/config';
import en from '../translations/en.json';
import te from '../translations/te.json';
import ur from '../translations/ur.json';

const DICTS = { en, te, ur };
const LanguageContext = createContext(null);

function getNested(obj, path) {
  return path.split('.').reduce((acc, key) => (acc && acc[key] !== undefined ? acc[key] : undefined), obj);
}

export function LanguageProvider({ children }) {
  const [language, setLanguageState] = useState(() => {
    return localStorage.getItem(APP.languageStorageKey) || null; // null = not chosen yet
  });

  const applyDirection = useCallback((code) => {
    const meta = SUPPORTED_LANGUAGES.find((l) => l.code === code);
    document.documentElement.lang = code;
    document.documentElement.dir = meta?.dir || 'ltr';
  }, []);

  useEffect(() => {
    if (language) applyDirection(language);
  }, [language, applyDirection]);

  const setLanguage = (code) => {
    localStorage.setItem(APP.languageStorageKey, code);
    setLanguageState(code);
  };

  // t('maintenance.payNow') -> looks up nested key, falls back to English, then the key itself
  const t = (key) => {
    const dict = DICTS[language || 'en'];
    const value = getNested(dict, key);
    if (value !== undefined) return value;
    const fallback = getNested(DICTS.en, key);
    return fallback !== undefined ? fallback : key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, languages: SUPPORTED_LANGUAGES }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error('useLanguage must be used within LanguageProvider');
  return ctx;
}
