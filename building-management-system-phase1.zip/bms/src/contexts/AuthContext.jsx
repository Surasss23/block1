import { createContext, useContext, useEffect, useState } from 'react';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../firebase/firebase';
import { subscribeToAuthChanges, logout as logoutService } from '../services/authService';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);       // Firebase Auth user object
  const [role, setRole] = useState(null);        // 'resident' | 'admin' | null
  const [profile, setProfile] = useState(null);  // Firestore document for the user
  const [initializing, setInitializing] = useState(true);

  useEffect(() => {
    const unsubscribe = subscribeToAuthChanges(async (firebaseUser) => {
      if (!firebaseUser) {
        setUser(null);
        setRole(null);
        setProfile(null);
        setInitializing(false);
        return;
      }
      setUser(firebaseUser);

      // Figure out whether this UID belongs to an admin or a resident.
      const adminSnap = await getDoc(doc(db, 'admins', firebaseUser.uid));
      if (adminSnap.exists()) {
        setRole('admin');
        setProfile(adminSnap.data());
      } else {
        const residentSnap = await getDoc(doc(db, 'residents', firebaseUser.uid));
        if (residentSnap.exists()) {
          setRole('resident');
          setProfile(residentSnap.data());
        } else {
          setRole(null);
          setProfile(null);
        }
      }
      setInitializing(false);
    });
    return unsubscribe;
  }, []);

  const logout = () => logoutService();

  return (
    <AuthContext.Provider value={{ user, role, profile, initializing, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
